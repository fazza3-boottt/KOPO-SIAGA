import { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";
import {
  AlertTriangle, Bell, CarFront, ChevronRight, CircleAlert, Clock3,
  Crosshair, MapPin, Menu, Navigation, Plus, Radio, Route, ShieldCheck,
  Siren, Waves, Wrench, X
} from "lucide-react";

// Titik tengah peta dan contoh laporan awal di koridor Bandung Kiwari–Katapang.
// Koordinat laporan contoh hanya untuk demonstrasi, bukan laporan kejadian aktual.
const CENTER = [-6.987, 107.574];
const INITIAL_REPORTS = [
  { id: 1, type: "banjir", title: "Contoh titik genangan", area: "Cigondewah", detail: "Data simulasi untuk demo. Periksa kondisi lapangan.", lat: -6.9705, lng: 107.5655, level: "sedang", time: "Contoh data" },
  { id: 2, type: "macet", title: "Contoh kepadatan lalu lintas", area: "Kopo", detail: "Data simulasi untuk demo.", lat: -6.991, lng: 107.574, level: "tinggi", time: "Contoh data" },
  { id: 3, type: "rusak", title: "Contoh jalan rusak", area: "Katapang", detail: "Data simulasi untuk demo.", lat: -7.020, lng: 107.574, level: "rendah", time: "Contoh data" },
  { id: 4, type: "banjir", title: "Contoh genangan", area: "TKI", detail: "Data simulasi untuk demo.", lat: -6.981, lng: 107.581, level: "rendah", time: "Contoh data" }
];

const TYPE = {
  banjir: { label: "Banjir", color: "#168bd2", Icon: Waves },
  macet: { label: "Macet", color: "#e58a22", Icon: CarFront },
  rusak: { label: "Jalan rusak", color: "#d64d4d", Icon: Wrench }
};

function makeIcon(type) {
  const color = TYPE[type]?.color || "#64748b";
  return L.divIcon({
    className: "report-marker-wrap",
    html: `<div class="report-marker" style="--marker-color:${color}"><span></span></div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });
}

function MapClickHandler({ onPick }) {
  useMapEvents({ click(e) { onPick([e.latlng.lat, e.latlng.lng]); } });
  return null;
}

function MapFocus({ target }) {
  const map = useMap();
  useEffect(() => { if (target) map.flyTo(target, 15, { duration: 0.8 }); }, [target, map]);
  return null;
}

function distanceToSegmentMeters(p, a, b) {
  const latScale = 111320;
  const lngScale = 111320 * Math.cos(p[0] * Math.PI / 180);
  const px = p[1] * lngScale, py = p[0] * latScale;
  const ax = a[1] * lngScale, ay = a[0] * latScale;
  const bx = b[1] * lngScale, by = b[0] * latScale;
  const dx = bx - ax, dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px-ax)*dx + (py-ay)*dy) / (dx*dx + dy*dy || 1)));
  return Math.hypot(px - (ax + t*dx), py - (ay + t*dy));
}

function routeHazardScore(coords, reports) {
  let score = 0;
  for (const r of reports) {
    const threshold = r.type === "banjir" ? 450 : r.type === "macet" ? 300 : 120;
    const near = coords.some((p, i) => i % 3 === 0 && distanceToSegmentMeters([r.lat, r.lng], p, coords[Math.min(i+1, coords.length-1)]) < threshold);
    if (near) score += r.type === "banjir" ? 100 : r.type === "macet" ? 40 : 25;
  }
  return score;
}

export default function App() {
  const [reports, setReports] = useState(INITIAL_REPORTS);
  const [filter, setFilter] = useState("semua");
  const [selected, setSelected] = useState(null);
  const [showReport, setShowReport] = useState(false);
  const [form, setForm] = useState({ type: "banjir", area: "Cigondewah", detail: "", level: "sedang" });
  const [picked, setPicked] = useState(null);
  const [destination, setDestination] = useState("Katapang, Kabupaten Bandung");
  const [routeCoords, setRouteCoords] = useState([]);
  const [routeInfo, setRouteInfo] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [location, setLocation] = useState(null);
  const [notificationOn, setNotificationOn] = useState(false);
  const [mobilePanel, setMobilePanel] = useState(false);

  const visibleReports = useMemo(() => reports.filter(r => filter === "semua" || r.type === filter), [reports, filter]);

  function toast(message) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 4200);
  }

  async function enableNotifications() {
    if (!("Notification" in window)) return toast("Browser ini belum mendukung notifikasi.");
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      setNotificationOn(true);
      new Notification("KOPO SIAGA aktif", { body: "Notifikasi laporan kondisi jalan telah diaktifkan." });
      toast("Notifikasi berhasil diaktifkan.");
    } else {
      toast("Izin notifikasi belum diberikan. Kamu bisa mengaktifkannya dari pengaturan browser.");
    }
  }

  function sendAlert(report) {
    const text = `${TYPE[report.type].label} dilaporkan di ${report.area}. ${report.detail}`;
    toast(text);
    if (notificationOn && "Notification" in window && Notification.permission === "granted") {
      new Notification(`KOPO SIAGA: ${TYPE[report.type].label}`, { body: `${report.area} — ${report.detail}` });
    }
  }

  function addReport(e) {
    e.preventDefault();
    if (!picked) return toast("Klik lokasi kejadian pada peta terlebih dahulu.");
    if (!form.detail.trim()) return toast("Tambahkan keterangan singkat kejadian.");
    const report = {
      id: Date.now(), ...form, title: `${TYPE[form.type].label} dilaporkan`,
      lat: picked[0], lng: picked[1], time: new Date().toLocaleString("id-ID")
    };
    setReports(prev => [report, ...prev]);
    setSelected(report);
    setShowReport(false);
    setPicked(null);
    setForm({ type: "banjir", area: "Cigondewah", detail: "", level: "sedang" });
    sendAlert(report);
  }

  function getMyLocation() {
    if (!navigator.geolocation) return toast("Browser tidak mendukung GPS.");
    navigator.geolocation.getCurrentPosition(
      p => {
        const point = [p.coords.latitude, p.coords.longitude];
        setLocation(point);
        toast("Lokasi kamu berhasil ditemukan.");
      },
      () => toast("Lokasi tidak bisa diakses. Periksa izin lokasi browser."),
      { enableHighAccuracy: true, timeout: 12000 }
    );
  }

  async function findRoute() {
    if (!location) return toast("Aktifkan lokasi GPS terlebih dahulu.");
    if (!destination.trim()) return toast("Masukkan tujuan perjalanan.");
    setBusy(true);
    setRouteCoords([]);
    setRouteInfo(null);
    try {
      const geo = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(destination + ", Kabupaten Bandung, Jawa Barat")}`);
      if (!geo.ok) throw new Error("Pencarian tujuan gagal.");
      const places = await geo.json();
      if (!places.length) throw new Error("Tujuan tidak ditemukan. Coba tulis nama tempat atau alamat lebih lengkap.");
      const end = [Number(places[0].lat), Number(places[0].lon)];
      const url = `https://router.project-osrm.org/route/v1/driving/${location[1]},${location[0]};${end[1]},${end[0]}?overview=full&geometries=geojson&alternatives=true&steps=true`;
      const response = await fetch(url);
      if (!response.ok) throw new Error("Layanan rute sedang tidak tersedia.");
      const data = await response.json();
      if (!data.routes?.length) throw new Error("Rute belum ditemukan.");
      const ranked = data.routes.map(route => ({
        route,
        score: routeHazardScore(route.geometry.coordinates.map(c => [c[1], c[0]]), reports.filter(r => r.type !== "rusak" || r.level !== "rendah"))
      })).sort((a,b) => a.score - b.score);
      const chosen = ranked[0].route;
      setRouteCoords(chosen.geometry.coordinates.map(c => [c[1], c[0]]));
      setRouteInfo({
        km: (chosen.distance / 1000).toFixed(1),
        min: Math.round(chosen.duration / 60),
        safer: ranked[0].score === 0,
        alternatives: data.routes.length
      });
      toast(ranked[0].score === 0 ? "Rute ditemukan. Tidak terdeteksi dekat dengan laporan aktif pada data aplikasi." : "Rute ditemukan. Periksa titik laporan dan kondisi jalan sebelum berangkat.");
    } catch (err) {
      toast(err.message || "Terjadi kesalahan saat mencari rute.");
    } finally {
      setBusy(false);
    }
  }

  const reportCount = type => reports.filter(r => r.type === type).length;

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><ShieldCheck size={24}/></div>
          <div><div className="brand-name">KOPO <span>SIAGA</span></div><div className="brand-sub">PANTAU JALAN • TETAP AMAN</div></div>
        </div>
        <div className="topbar-right">
          <span className="live-dot"></span><span className="live-text">PETA WILAYAH</span>
          <button className="icon-button" onClick={enableNotifications} title="Aktifkan notifikasi"><Bell size={19}/></button>
          <button className="mobile-menu" onClick={() => setMobilePanel(v => !v)}><Menu size={21}/></button>
        </div>
      </header>

      <main className="layout">
        <aside className={`sidebar ${mobilePanel ? "sidebar-open" : ""}`}>
          <div className="intro">
            <div className="eyebrow">KORIDOR PEMANTAUAN</div>
            <h1>Perjalanan lebih <em>siaga.</em></h1>
            <p>Pantau banjir, kemacetan, dan kondisi jalan di Bandung Kiwari hingga Katapang.</p>
          </div>

          <section className="route-card">
            <div className="section-heading"><Navigation size={16}/> Cari rute perjalanan</div>
            <label className="field-label">TUJUAN</label>
            <input value={destination} onChange={e => setDestination(e.target.value)} placeholder="Contoh: Katapang"/>
            <div className="location-row">
              <span className={`location-status ${location ? "found" : ""}`}></span>
              <span>{location ? "Lokasi GPS terdeteksi" : "Lokasi awal belum terdeteksi"}</span>
              <button className="text-button" onClick={getMyLocation}><Crosshair size={14}/> GPS</button>
            </div>
            <button className="primary-button" onClick={findRoute} disabled={busy}>
              <Route size={17}/>{busy ? "Mencari rute..." : "Cari rute aman"}<ChevronRight size={17}/>
            </button>
            {routeInfo && <div className="route-result">
              <div className="route-result-top"><strong>Rute rekomendasi</strong><span className="safe-label">{routeInfo.safer ? "Minim laporan" : "Perlu waspada"}</span></div>
              <div className="route-metrics"><div><strong>{routeInfo.km} km</strong><small>Jarak</small></div><div><strong>{routeInfo.min} menit</strong><small>Estimasi</small></div><div><strong>{routeInfo.alternatives}</strong><small>Opsi rute</small></div></div>
              <p>Estimasi dari layanan rute; kondisi aktual dapat berubah. Tetap ikuti rambu dan arahan petugas.</p>
            </div>}
          </section>

          <section className="status-section">
            <div className="section-heading"><Radio size={16}/> Ringkasan laporan</div>
            <div className="stats-grid">
              <button className={`stat-card blue ${filter === "banjir" ? "stat-active" : ""}`} onClick={() => setFilter(filter === "banjir" ? "semua" : "banjir")}><Waves/><strong>{reportCount("banjir")}</strong><span>Banjir</span></button>
              <button className={`stat-card orange ${filter === "macet" ? "stat-active" : ""}`} onClick={() => setFilter(filter === "macet" ? "semua" : "macet")}><CarFront/><strong>{reportCount("macet")}</strong><span>Macet</span></button>
              <button className={`stat-card red ${filter === "rusak" ? "stat-active" : ""}`} onClick={() => setFilter(filter === "rusak" ? "semua" : "rusak")}><Wrench/><strong>{reportCount("rusak")}</strong><span>Jalan rusak</span></button>
            </div>
            <div className="filter-line"><span>Menampilkan: <b>{filter === "semua" ? "Semua laporan" : TYPE[filter].label}</b></span><button onClick={() => setFilter("semua")}>Reset filter</button></div>
          </section>

          <section className="reports-section">
            <div className="section-heading"><CircleAlert size={16}/> Laporan terkini <span className="count-badge">{visibleReports.length}</span></div>
            <div className="report-list">
              {visibleReports.map(r => {
                const Icon = TYPE[r.type].Icon;
                return <button className={`report-item ${selected?.id === r.id ? "report-selected" : ""}`} key={r.id} onClick={() => { setSelected(r); setPicked([r.lat, r.lng]); }}>
                  <div className="report-icon" style={{ color: TYPE[r.type].color, background: `${TYPE[r.type].color}15` }}><Icon size={18}/></div>
                  <div className="report-copy"><strong>{r.title}</strong><span>{r.area} · {r.time}</span><small>{r.detail}</small></div>
                  <ChevronRight size={16} className="report-arrow"/>
                </button>;
              })}
              {!visibleReports.length && <div className="empty-state">Belum ada laporan untuk kategori ini.</div>}
            </div>
          </section>

          <button className="report-button" onClick={() => setShowReport(true)}><Plus size={18}/> Laporkan kondisi jalan</button>
          <div className="sidebar-foot"><ShieldCheck size={14}/> Utamakan keselamatan. Jangan gunakan ponsel saat berkendara.</div>
        </aside>

        <section className="map-area">
          <div className="map-toolbar">
            <div><MapPin size={16}/><span>Bandung Kiwari — Cigondewah — TKI — Kopo — Katapang</span></div>
            <button onClick={() => { setSelected(null); setPicked(null); setRouteCoords([]); setRouteInfo(null); }}><X size={15}/> Bersihkan peta</button>
          </div>
          <div className="map-frame">
            <MapContainer center={CENTER} zoom={13} scrollWheelZoom={true}>
              <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
              <MapClickHandler onPick={setPicked}/>
              <MapFocus target={selected ? [selected.lat, selected.lng] : picked}/>
              {visibleReports.map(r => <Marker key={r.id} position={[r.lat, r.lng]} icon={makeIcon(r.type)} eventHandlers={{ click: () => setSelected(r) }}>
                <Popup><div className="popup-content"><b>{r.title}</b><br/>{r.area}<br/><span>{r.detail}</span><small>{r.time}</small></div></Popup>
              </Marker>)}
              {location && <Marker position={location}><Popup>Lokasi kamu</Popup></Marker>}
              {picked && <Marker position={picked}><Popup>Lokasi yang dipilih untuk laporan</Popup></Marker>}
              {routeCoords.length > 0 && <Polyline positions={routeCoords} pathOptions={{ color: "#1769aa", weight: 6, opacity: .88 }}/>}
            </MapContainer>
            <div className="map-legend">
              <div><i className="legend-dot flood"></i>Banjir</div><div><i className="legend-dot traffic"></i>Macet</div><div><i className="legend-dot damage"></i>Jalan rusak</div><div><i className="legend-line"></i>Rute</div>
            </div>
            <button className="map-gps" onClick={getMyLocation} title="Temukan lokasi saya"><Crosshair size={19}/></button>
            <div className="map-disclaimer">Peta © OpenStreetMap · Titik contoh bukan informasi kejadian aktual</div>
          </div>
          <div className="map-bottom">
            <div className="map-bottom-icon"><Siren size={20}/></div>
            <div><strong>Kenali kondisi sebelum berangkat</strong><span>Informasi dari laporan pengguna perlu diverifikasi. Jangan menerobos genangan atau penutupan jalan.</span></div>
            <button onClick={() => setShowReport(true)}>Buat laporan <ChevronRight size={16}/></button>
          </div>
        </section>
      </main>

      {showReport && <div className="modal-backdrop" onClick={() => setShowReport(false)}>
        <form className="report-modal" onSubmit={addReport} onClick={e => e.stopPropagation()}>
          <div className="modal-heading"><div><span className="eyebrow">KONTRIBUSI PENGGUNA</span><h2>Laporkan kondisi jalan</h2></div><button type="button" className="close-button" onClick={() => setShowReport(false)}><X/></button></div>
          <p className="modal-hint">Pilih titik kejadian dengan mengeklik lokasi pada peta, lalu isi informasi di bawah.</p>
          <label className="field-label">JENIS LAPORAN</label>
          <div className="type-options">
            {Object.entries(TYPE).map(([key, item]) => <button type="button" key={key} className={form.type === key ? "type-option chosen" : "type-option"} onClick={() => setForm({ ...form, type: key })}><item.Icon size={18}/>{item.label}</button>)}
          </div>
          <label className="field-label">WILAYAH</label>
          <select value={form.area} onChange={e => setForm({ ...form, area: e.target.value })}>
            {["Bandung Kiwari","Cigondewah","TKI","Kopo","Margahayu","Katapang","Lainnya"].map(a => <option key={a}>{a}</option>)}
          </select>
          <label className="field-label">TINGKAT KEJADIAN</label>
          <select value={form.level} onChange={e => setForm({ ...form, level: e.target.value })}><option value="rendah">Rendah</option><option value="sedang">Sedang</option><option value="tinggi">Tinggi</option></select>
          <label className="field-label">KETERANGAN</label>
          <textarea rows="3" value={form.detail} onChange={e => setForm({ ...form, detail: e.target.value })} placeholder="Contoh: genangan menutupi sebagian lajur..."/>
          <div className={`picked-info ${picked ? "picked-ok" : ""}`}><MapPin size={16}/>{picked ? `Titik dipilih: ${picked[0].toFixed(5)}, ${picked[1].toFixed(5)}` : "Belum ada titik. Klik lokasi pada peta."}</div>
          <button className="primary-button submit-report" type="submit"><Plus size={17}/> Kirim laporan</button>
          <p className="form-note">Prototype: laporan tersimpan sementara di browser dan belum dikirim ke server publik.</p>
        </form>
      </div>}
      {notice && <div className="toast"><AlertTriangle size={17}/>{notice}</div>}
    </div>
  );
}