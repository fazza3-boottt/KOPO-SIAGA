# KOPO SIAGA

Prototype web pemantauan banjir, kemacetan, dan jalan rusak untuk koridor Bandung Kiwari–Cigondewah–TKI–Kopo–Katapang.

## Menjalankan di VS Code

1. Install **Node.js versi LTS** dari https://nodejs.org
2. Ekstrak folder `kopo-siaga`.
3. Buka folder tersebut di VS Code.
4. Buka Terminal → New Terminal.
5. Jalankan:

   ```bash
   npm install
   npm run dev
   ```

6. Buka alamat lokal yang muncul di terminal (biasanya `http://localhost:5173`).

## Fitur prototype

- Peta interaktif OpenStreetMap.
- Marker laporan banjir, macet, dan jalan rusak.
- Filter kategori laporan.
- Form laporan dengan memilih titik langsung pada peta.
- Notifikasi browser setelah izin diberikan.
- GPS perangkat.
- Pencarian tujuan dan rute dari OSRM.
- Pemilihan rute alternatif berdasarkan kedekatan terhadap titik laporan yang sedang tersimpan di aplikasi.

## Penting: batasan versi demo

- Titik awal yang tampil di peta adalah **data simulasi**, bukan informasi kejadian banjir/macet/jalan rusak yang terverifikasi.
- Laporan yang dikirim dari form hanya tersimpan sementara dalam state aplikasi. Data akan hilang saat halaman dimuat ulang.
- Notifikasi pada versi ini aktif saat laporan baru dimasukkan ke aplikasi yang sedang dibuka. Belum ada notifikasi otomatis dari server ketika pengguna menutup browser.
- Pencarian nama tempat menggunakan Nominatim dan rute menggunakan layanan demo OSRM. Keduanya memerlukan internet dan memiliki batas penggunaan; bukan layanan produksi dengan jaminan uptime.
- Algoritma rute hanya memilih dari alternatif yang diberikan OSRM dan memberi penalti pada rute yang dekat dengan titik laporan lokal. Ini **bukan jaminan rute bebas banjir atau macet**. Selalu cek kondisi aktual, rambu, dan arahan petugas.
- Peta dan cakupan jalan mengikuti ketersediaan data OpenStreetMap. Periksa kembali nama jalan dan batas wilayah.

## Pengembangan sebelum dipakai publik

1. Buat backend dan database (misalnya Supabase/PostgreSQL) untuk menyimpan laporan.
2. Tambahkan akun pengguna, moderasi, bukti foto, waktu kejadian, dan status verifikasi.
3. Buat panel admin/operator untuk memvalidasi laporan.
4. Gunakan sumber resmi/terverifikasi untuk peringatan banjir dan rekayasa lalu lintas.
5. Tambahkan layanan notifikasi push melalui server (misalnya Firebase Cloud Messaging).
6. Untuk navigasi produksi, gunakan penyedia routing yang mendukung pembatasan jalan/penutupan jalan secara resmi dan punya SLA.
7. Terapkan kebijakan privasi dan jangan tampilkan identitas pelapor secara publik.

## Struktur

```text
kopo-siaga/
├── index.html
├── package.json
├── README.md
└── src/
    ├── App.jsx
    ├── main.jsx
    └── style.css
```
